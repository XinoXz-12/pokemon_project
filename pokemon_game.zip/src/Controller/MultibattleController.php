<?php

namespace App\Controller;

use App\Entity\Pokedex;
use App\Repository\UserRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class MultibattleController extends AbstractController
{
    #[Route('/multibattle', name: 'app_multibattle')]
    public function index(UserRepository $userRepository, EntityManagerInterface $entityManager): Response
    {
        $rivals = $userRepository->search_rivals($this->getUser());


        $user = $userRepository->findOneBy(array('id' => $this->getUser()));
        $pokedex = $entityManager->getRepository(Pokedex::class)->findOneBy(['trainer' => $user]);
        // Si no existe una Pokedex o está vacía, lo enviamos a cazar
        if (!$pokedex || $pokedex->getpokedexPokemons()->isEmpty()) {
            return $this->redirectToRoute('app_user_catch');
        }

        return $this->render('multibattle/index.html.twig', [
            'rivals' => $rivals,
        ]);
    }

    #[Route('/multibattle/vs', name: 'app_multi_vs', methods: ['GET'])]
    public function vs1(UserRepository $userRepository, EntityManagerInterface $entityManager, Request $request): Response
    {
        $user = $userRepository->findOneBy(array('id' => $this->getUser()));
        $pokedex = $entityManager->getRepository(Pokedex::class)->findOneBy(['trainer' => $user]);

        // Me traigo las variables pasadas por el metodo get en la url
        $id_rival = $request->query->get('id_rival');
        $rival = $userRepository->findOneBy(array('id' => $id_rival));
        $pokedex_rival = $entityManager->getRepository(Pokedex::class)->findOneBy(['trainer' => $rival]);

        $vs = $request->query->get('vs');

        // Me traigo mis pokemon de mi pokedex
        $pokemons = $pokedex->getpokedexPokemons();

        // Me traigo los pokemon de la pokedex del rival
        $rival_pokemons = $pokedex_rival->getpokedexPokemons();

        // Manejamos la elección de combate
        if (isset($vs)) {
            switch ($vs) {
                case '3':
    
                    return $this->render('multibattle/select_pokemon.html.twig', ['pokemons' => $pokemons, 'pokemons_rival' => $rival_pokemons, 'id_rival' => $id_rival, 'vs' => $vs]);
                    break;
    
                case '5':
    
                    return $this->render('multibattle/select_pokemon.html.twig', ['pokemons' => $pokemons, 'pokemons_rival' => $rival_pokemons, 'id_rival' => $id_rival, 'vs' => $vs]);
                    break;
            }
        }

        return $this->render('multibattle/select_pokemon.html.twig', ['pokemons' => $pokemons, 'pokemons_rival' => $rival_pokemons, 'id_rival' => $id_rival]);
    }

    // #[Route('/multibattle', name: 'app_multi_vs1_logical')]
    // public function vs1_logical(UserRepository $userRepository, EntityManagerInterface $entityManager, PokemonRepository $pokemonRepository, PokedexPokemonRepository $pokedexPokemonRepository): void
    // {
    //     $user = $userRepository->findOneBy(array('id' => $this->getUser()));
    //     $pokedex = $entityManager->getRepository(Pokedex::class)->findOneBy(['trainer' => $user]);

    //     // Me traigo el pokemon enemigo
    //     $enemy = $pokemonRepository->find($request->query->get('id_enemy'));

    //     // Me traigo a mi pokemon de mi pókedex
    //     $ally = $pokedexPokemonRepository->findBy(['pokemon' => $request->query->get('id_ally')])[0];

    //     // Calculo sus poderes
    //     $ally_power = $ally->getLevel() * $ally->getStrength();
    //     $enemy_power = $enemy->getLevel() * $enemy->getStrength();

    //     // El pokemon con el mayor poder gana, si gana el ally le suma 1 nivel
    //     if ($ally_power > $enemy_power) {

    //         // Guardamos la información de la batalla en la base de datos
    //         $battle = new Multibattle();
    //         $battle->setAllyPokearray($ally->getPokemon());
    //         $battle->setRivalPokearray($enemy);
    //         $battle->setAllyTrainer($user);
    //         $battle->setResult($ally_power > $enemy_power ? 1 : 0);
    //         $entityManager->persist($battle);
    //         $entityManager->flush();
    //     } else if ($ally_power < $enemy_power) {
    //         $ally->setInjured(true);
    //         $entityManager->persist($ally);
    //         $entityManager->flush();

    //         // Guardamos la información de la batalla en la base de datos
    //         $battle = new Multibattle();
    //         $battle->setAllyPokearray($ally->getPokemon());
    //         $battle->setRivalPokearray($enemy);
    //         $battle->setAllyTrainer($user);
    //         $battle->setResult($ally_power > $enemy_power ? 1 : 0);
    //         $entityManager->persist($battle);
    //         $entityManager->flush();
    //     }
    // }

    #[Route('/multibattle', name: 'app_multi_vsmulti_logical')]
    public function vsMulti_logical(UserRepository $userRepository): Response
    {
        $rivals = $userRepository->search_rivals($this->getUser());

        return $this->render('multibattle/index.html.twig', [
            'rivals' => $rivals,
        ]);
    }
}
